<?php

/**
 * Return the sum of two numbers
 *
 * @param integer $a The first number
 * @param integer $b The second number
 *
 * @return integer The sum of the two numbers
 */
function add($a, $b) {

    return $a + $b;

}
